In this part you will implement some functions that are often used in functional programming.
The expected behaviour of these functions is discussed in the lectures and can be found in the slides as well as the comments.

This part is worth 30 points.
For the exercises in this part you are _not_ allowed to use library functions.
